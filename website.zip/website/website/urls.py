from django.contrib import admin
from django.urls import include, path
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('competition/', include('competition.urls')),
    path('speech/', include('speech.urls')),
    path('', include('news.urls','base.urls')),
    path('about_us/', include('about_us.urls')),
    path('dashboard/', include('dashboard.urls')),
    path('base/', include('base.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
