from django.shortcuts import render, redirect
from django.contrib.auth import logout, login, authenticate, update_session_auth_hash
from django.contrib import messages

from competition.models import Favorite, Competition
from speech.models import Speech, Favorites
from .forms import EditProfileForm
from django.contrib.auth.forms import PasswordChangeForm
from base.forms import ContactForm
from django.core.mail import send_mail
from .forms import UserForm
from django.contrib.auth.models import User


# Create your views here.
def events_list(request):
    if request.user.is_authenticated:
        current_user = User.objects.get(username=request.user)
        favorite_competitions = Favorite.objects.filter(member=request.user).all()
        all_competitions = Competition.objects.all().order_by("-date")
        favorite_comp_list = []
        for fav in favorite_competitions:
            favorite_comp_list.append(fav.competition)
        favorite_speeches = Favorites.objects.filter(member=request.user).all()
        all_speeches = Speech.objects.all().order_by("-date")
        favorite_speech_list = []

        for fav in favorite_speeches:
            favorite_speech_list.append(fav.speech)
        return render(request, 'base/events_list.html',
                      {'all_competitions': all_competitions[:4], 'current_user': current_user,
                       'favorite_comp_list': favorite_comp_list, 'all_speeches': all_speeches[:4],
                       'favorite_speech_list': favorite_speech_list})
    else:
        return render(request, 'base/error_page.html')


def register(request):
    form = UserForm(request.POST or None, request.FILES or None)
    if form.is_valid():
        user = form.save(commit=False)
        # username = form.cleaned_data['username']
        # password = form.cleaned_data['password']
        # user.set_password(password)
        user.save()
        # user = authenticate(username=username, password=password)

        if user is not None:
            if user.is_active:
                login(request, user)
                return render(request, 'dashboard/dashboard.html')

    else:
        context = {
            'form': form
        }
        return render(request, 'base/register.html', context)


def forgot_password(request):
    form = ContactForm(request.POST or None)
    user = request.user
    # new logic!
    if form.is_valid():
        form_email = form.cleaned_data.get("email_address")
        subject = str(user) + ' requests new password!'
        from_email = form_email
        to_email = 'vasilisvittis1@gmail.com'
        contact_message = " %s: via %s" % (user, form_email)
        send_mail(subject, contact_message, from_email, [to_email], fail_silently=False)
        messages.success(request, 'Thank you for your email we will contact you soon!')
    context = {
        'form': form
    }
    return render(request, 'base/forget_password.html', context)


def logout_d(request):
    logout(request)
    return render(request, 'base/logout.html')


def login_d(request):
    username = request.POST['username']
    password = request.POST['password']
    user = authenticate(request, username=username, password=password)
    if user is not None:
        login(request, user)
        return redirect('dashboard:dashboard')
    else:
        messages.warning(request, 'This user does not exist Try Log In or Register')
        return redirect('news:index')


def settings(request):
    if request.user.is_authenticated:
        current_user = request.user
        form = EditProfileForm(request.POST or None, instance=request.user,
                               initial={'username': request.user.username, 'first_name': request.user.first_name,
                                        'last_name': request.user.last_name, 'email': request.user.email,
                                        'password': None})
        if form.is_valid():
            form.save()
            context = {
                'form': form,
                'current_user': current_user
            }
            messages.success(request, 'You have successfully changed your data')
            return render(request, 'base/settings.html', context)
        else:
            context = {
                'form': form,
                'current_user': current_user
            }
            return render(request, 'base/settings.html', context)
    else:
        return render(request, 'base/error_page.html')


def change_password(request):
    if request.user.is_authenticated:
        form = PasswordChangeForm(data=request.POST, user=request.user)
        if form.is_valid():
            form.save()
            update_session_auth_hash(request, form.user)
            context = {
                'form': form
            }
            messages.success(request, 'You have successfully changed your data')
            return render(request, 'base/change_password.html', context)
        else:
            context = {
                'form': form,
            }
            return render(request, 'base/change_password.html', context)
    else:
        return render(request, 'base/error_page.html')
