from django.contrib.auth.forms import UserChangeForm, UserCreationForm
from django.contrib.auth.models import User
from django import forms


class EditProfileForm(UserChangeForm):
    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email']


class ContactForm(forms.Form):
    email_address = forms.EmailField(required=True, widget=forms.TextInput(attrs={'placeholder': 'Email'}))


class UserForm(UserCreationForm):
    # first_name = forms.CharField(max_length=30, required=False,
    #                              widget=forms.TextInput(attrs={'placeholder': 'Optional'}))
    # last_name = forms.CharField(max_length=30, required=False,
    #                             widget=forms.TextInput(attrs={'placeholder': 'Optional'}))
    # email = forms.EmailField(required=True, widget=forms.TextInput(attrs={'placeholder': 'Enter TUC email'}))
    # password = forms.CharField(max_length=32, required=True, widget=forms.PasswordInput)
    # confirm_password = forms.CharField(max_length=32, required=True, widget=forms.PasswordInput)
    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email']
