from .models import Competition, Team, Compete, Belong, Favorite
from django.contrib.auth.models import User
from django.shortcuts import get_object_or_404, render, redirect
from django.views import generic
from .forms import TeamForm
from django.contrib import messages


# Create your views here.


def index_view(request):
    if request.user.is_authenticated:
        current_user = User.objects.get(username=request.user)
        favorite_competitions = Favorite.objects.filter(member=request.user).all()
        all_competitions = Competition.objects.all().order_by("-date")
        favorite_comp_list = []
        for fav in favorite_competitions:
            favorite_comp_list.append(fav.competition)
        return render(request, 'competition/index.html',
                      {'all_competitions': all_competitions[4:], 'current_user': current_user,
                       'favorite_comp_list': favorite_comp_list})
    else:
        return render(request, 'base/error_page.html')


def detail_view(request, competition_id):
    if request.user.is_authenticated:
        comp = get_object_or_404(Competition, id=competition_id)
        return render(request, 'competition/detail.html', {'comp': comp})
    else:
        return render(request, 'base/error_page.html')


# Validation for url
def create_team(request, competition_id):
    if request.user.is_authenticated:
        form = TeamForm(request.POST or None, request.FILES or None)
        competition = get_object_or_404(Competition, pk=competition_id)
        flag = 0
        for par in competition.participants.all():
            if request.user in par.team_members.all():
                flag = 1
        if flag == 0:
            compete = Compete()
            belong = Belong()
            compete.competing_to = competition
            if form.is_valid():
                team = form.save(commit=False)
                team.team_logo = request.FILES['team_logo']
                team.save()
                belong.team = team
                belong.member = request.user
                belong.save()
                compete.team_competing = team
                compete.save()
                return render(request, 'competition/detail.html', {'comp': competition})
            context = {
                'comp': competition,
                'form': form,
            }
            return render(request, 'competition/team_form.html', context)
        else:
            messages.warning(request, 'You can not create a new team because you are already joining another one!')
        return render(request, 'competition/detail.html', {'comp': competition})
    else:
        return render(request, 'base/error_page.html')


def delete_team(request, competition_id, team_id):
    if request.user.is_authenticated:
        competition = get_object_or_404(Competition, pk=competition_id)
        team = Team.objects.get(pk=team_id)
        members = team.team_members.all()
        if request.user == members[0]:
            team.delete()
        else:
            messages.warning(request, 'You have not the privilege to do anything on this team!')
        return render(request, 'competition/detail.html', {'comp': competition})
    else:
        return render(request, 'base/error_page.html')


def join_team(request, competition_id, team_id):
    if request.user.is_authenticated:
        competition = get_object_or_404(Competition, pk=competition_id)
        team = get_object_or_404(Team, pk=team_id)
        flag = 0
        for par in competition.participants.all():
            if request.user in par.team_members.all():
                flag = 1
        if flag == 0:
            belong = Belong()
            belong.team = team
            belong.member = request.user
            belong.save()
        else:
            messages.warning(request, 'You can not join more than one team in the same competition!')
        return render(request, 'competition/detail.html', {'comp': competition})
    else:
        return render(request, 'base/error_page.html')


def leave_team(request, competition_id, team_id):
    if request.user.is_authenticated:
        competition = get_object_or_404(Competition, pk=competition_id)
        team = get_object_or_404(Team, pk=team_id)
        if team.team_members.count() == 1:
            return render(request, 'competition/confirm_team_delete.html', {'comp': competition, 'team': team})
            # messages.warning(request, 'If you leave, the team will be automatically deleted!')
        else:
            belong = Belong.objects.get(member=request.user, team=team)
            belong.delete()
            return render(request, 'competition/detail.html', {'comp': competition})
    else:
        return render(request, 'base/error_page.html')


def update_team(request, competition_id, team_id):
    if request.user.is_authenticated:
        competition = get_object_or_404(Competition, pk=competition_id)
        team = get_object_or_404(Team, pk=team_id)
        members = team.team_members.all()
        if request.user == members[0]:
            form = TeamForm(request.POST or None, request.FILES or None,
                            initial={'team_name': team.team_name, 'team_logo': team.team_logo})
            if form.is_valid():
                team.team_name = form.cleaned_data.get("team_name")
                team.team_logo = form.cleaned_data['team_logo']
                team.save()
                return render(request, 'competition/detail.html', {'comp': competition})
            context = {
                'comp': competition,
                'form': form,
            }
            return render(request, 'competition/team_form.html', context)
        else:
            messages.warning(request, 'You have not the privilege to do anything on this team!')
            return render(request, 'competition/detail.html', {'comp': competition})
    else:
        return render(request, 'base/error_page.html')


# Unexpected Problem each time you RELOAD /competition/<competition_id>/favorite basically you call the below function,
# so you change the status of competition and variable is_favorite


def favorite_competition(request, competition_id):
    if request.user.is_authenticated:
        comp = get_object_or_404(Competition, pk=competition_id)
        try:
            if Favorite.objects.filter(member=request.user, competition=comp).exists():
                fav = Favorite.objects.get(member=request.user, competition=comp)
                fav.delete()
            else:
                fav = Favorite()
                fav.member = request.user
                fav.competition = comp
                fav.save()
        except (KeyError, Competition.DoesNotExist):
            return redirect('base:events_list')
        else:
            return redirect('base:events_list')
    else:
        return render(request, 'base/error_page.html')
