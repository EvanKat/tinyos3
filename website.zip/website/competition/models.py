from django.db import models
from django.contrib.auth.models import User


# Create your models here.


class Team(models.Model):
    team_name = models.CharField(max_length=250)
    team_logo = models.ImageField(upload_to="images")
    team_members = models.ManyToManyField(User, through='Belong')

    def __str__(self):
        return self.team_name

    def get_team_id(self):
        return Team.objects.get(pk=self)


class Competition(models.Model):
    name = models.CharField(max_length=250)
    logo = models.ImageField(upload_to="images")
    place = models.CharField(max_length=250, null=True)
    competition_description = models.TextField()
    date = models.DateTimeField()
    participants = models.ManyToManyField(Team, through='Compete')
    expired = models.BooleanField(default=False)
    notification = models.TextField(null=True, blank=True)

    def __str__(self):
        return self.name


class Photos(models.Model):
    competition = models.ForeignKey(Competition, on_delete=models.CASCADE)
    picture1 = models.ImageField(upload_to="images",null=True, blank=True)
    picture2 = models.ImageField(upload_to="images",null=True, blank=True)
    picture3 = models.ImageField(upload_to="images",null=True, blank=True)
    picture4 = models.ImageField(upload_to="images",null=True, blank=True)
    picture5 = models.ImageField(upload_to="images",null=True, blank=True)
    picture6 = models.ImageField(upload_to="images",null=True, blank=True)

    def __str__(self):
        return self.competition.name

class Compete(models.Model):
    team_competing = models.ForeignKey(Team, on_delete=models.CASCADE)
    competing_to = models.ForeignKey(Competition, on_delete=models.CASCADE)

    def __str__(self):
        return self.team_competing.team_name + " competes " + self.competing_to.name


class Belong(models.Model):
    member = models.ForeignKey(User, on_delete=models.CASCADE)
    team = models.ForeignKey(Team, on_delete=models.CASCADE)


class Favorite(models.Model):
    member = models.ForeignKey(User, on_delete=models.CASCADE)
    competition = models.ForeignKey(Competition, on_delete=models.CASCADE)

    def __str__(self):
        return self.member.username + "  " + self.competition.name


class Score(models.Model):
    team = models.ForeignKey(Team, on_delete=models.CASCADE)
    competition = models.ForeignKey(Competition, on_delete=models.CASCADE)
    score = models.IntegerField(default=0)

    def __str__(self):
        return str(self.team) + "has scored " + str(self.score) + " points  at " + str(self.competition) + str(
            self.competition_id)
