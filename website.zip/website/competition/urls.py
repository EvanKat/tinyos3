from django.urls import path
from . import views

app_name = 'competition'

urlpatterns = [
    # /competition/
    path('', views.index_view, name='index'),

    # /competition/<competition id>/

    path('<competition_id>/', views.detail_view, name='detail'),

    # /competition/<competition_id>/favorite
    path('<competition_id>/favorite/', views.favorite_competition, name='favorite_competition'),

    # /competition/<competition_id>/favorite
    path('<competition_id>/create_team/', views.create_team,  name='create_team'),

    # /competition/<competition_id>/delete_team/<team_id>
    path('<competition_id>/delete_team/<team_id>', views.delete_team, name='delete_team'),

    # /competition/<competition_id>/update_team/<team_id>
    path('<competition_id>/join_team/<team_id>', views.join_team, name='join_team'),

    # /competition/<competition_id>/leave_team/<team_id>
    path('<competition_id>/leave_team/<team_id>', views.leave_team, name='leave_team'),

    # /competition/<competition_id>/update_team/<team_id>
    path('<competition_id>/update_team/<team_id>', views.update_team, name='update_team')
]
