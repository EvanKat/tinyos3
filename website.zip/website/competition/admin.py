from django.contrib import admin
from .models import Competition, Team, Belong, Compete, Favorite, Score, Photos

# Register your models here.

admin.site.register(Competition)
admin.site.register(Team)
admin.site.register(Belong)
admin.site.register(Compete)
admin.site.register(Favorite)
admin.site.register(Score)

admin.site.register(Photos)
