from django.contrib import admin
from .models import Attend, Speech, Favorites,Photos1

# Register your models here.

admin.site.register(Speech)
admin.site.register(Attend)
admin.site.register(Photos1)
admin.site.register(Favorites)
