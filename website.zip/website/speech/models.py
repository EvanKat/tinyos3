from django.db import models
from django.contrib.auth.models import User


# Create your models here.


class Speech(models.Model):
    name = models.CharField(max_length=250)
    logo = models.ImageField(upload_to="images")
    place = models.CharField(max_length=250)
    speech_description = models.TextField()
    date = models.DateTimeField()
    attendants = models.ManyToManyField(User, through='Attend')
    expired = models.BooleanField(default=False)
    notifications = models.TextField(null=True, blank=True)


    def __str__(self):
        return self.name


class Photos1(models.Model):
    speech = models.ForeignKey(Speech, on_delete=models.CASCADE)
    picture1 = models.ImageField(upload_to="images", null=True, blank=True)
    picture2 = models.ImageField(upload_to="images", null=True, blank=True)
    picture3 = models.ImageField(upload_to="images", null=True, blank=True)
    picture4 = models.ImageField(upload_to="images", null=True, blank=True)
    picture5 = models.ImageField(upload_to="images", null=True, blank=True)
    picture6 = models.ImageField(upload_to="images", null=True, blank=True)





def __str__(self):
    return self.speech.name


class Attend(models.Model):
    user_attending = models.ForeignKey(User, on_delete=models.CASCADE)
    attending_to = models.ForeignKey(Speech, on_delete=models.CASCADE)


class Favorites(models.Model):
    member = models.ForeignKey(User, on_delete=models.CASCADE)
    speech = models.ForeignKey(Speech, on_delete=models.CASCADE)

    def __str__(self):
        return self.member.username + "  " + self.speech.name
