from django.apps import AppConfig


class SpeechConfig(AppConfig):
    name = 'speech'
