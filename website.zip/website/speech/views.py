from django.contrib import messages
from .models import Speech, Attend, Favorites
from django.shortcuts import get_object_or_404, render, redirect
from django.views import generic
from django.contrib.auth.models import User


# Create your views here.

def index_view(request):
    if request.user.is_authenticated:
        current_user = User.objects.get(username=request.user)
        favorite_speeches = Favorites.objects.filter(member=request.user).all()
        all_speeches = Speech.objects.all().order_by("-date")
        favorite_speech_list = []
        for fav in favorite_speeches:
            favorite_speech_list.append(fav.speech)
        return render(request, 'speech/index.html',
                      {'all_speeches': all_speeches[4:], 'current_user': current_user,
                       'favorite_speech_list': favorite_speech_list})
    else:
        return render(request, 'base/error_page.html')


def detail_view(request, speech_id):
    if request.user.is_authenticated:
        speech = get_object_or_404(Speech, id=speech_id)
        return render(request, 'speech/detail.html', {'speech': speech})
    else:
        return render(request, 'base/error_page.html')


def enroll(request, speech_id):
    if request.user.is_authenticated:
        speech = get_object_or_404(Speech, pk=speech_id)
        if request.user in speech.attendants.all():
            messages.warning(request, 'You can not participate more than one time in the same event')
        else:
            attend = Attend()
            attend.user_attending = request.user
            attend.attending_to = speech
            attend.save()
            messages.success(request, 'You successfully enrolled in this event')
        return render(request, 'speech/detail.html', {'speech': speech})
    else:
        return render(request, 'base/error_page.html')


def leave(request, speech_id):
    if request.user.is_authenticated:
        speech = get_object_or_404(Speech, pk=speech_id)
        attend = get_object_or_404(Attend, attending_to=speech_id, user_attending=request.user)
        attend.delete()
        messages.success(request, 'You successfully left this event')
        return render(request, 'speech/detail.html', {'speech': speech})
    else:
        return render(request, 'base/error_page.html')


def favorite_speech(request, speech_id):
    if request.user.is_authenticated:
        speech = get_object_or_404(Speech, pk=speech_id)
        try:
            if Favorites.objects.filter(member=request.user, speech=speech).exists():
                fav = Favorites.objects.get(member=request.user, speech=speech)
                fav.delete()
            else:
                fav = Favorites()
                fav.member = request.user
                fav.speech = speech
                fav.save()
        except (KeyError, Speech.DoesNotExist):
            return redirect('base:events_list')
        else:
            return redirect('base:events_list')
    else:
        return render(request, 'base/error_page.html')
