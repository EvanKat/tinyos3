from django.urls import path
from . import views

app_name = 'speech'
urlpatterns = [

    # /speech/
    path('', views.index_view, name='index'),

    # /speech/<speech id>/
    path('<speech_id>/', views.detail_view, name='detail'),

    # /speech/<speech id>/
    path('<speech_id>/enroll/', views.enroll, name='enroll'),

    # /speech/<speech id>/
    path('<speech_id>/leave/', views.leave, name='leave'),
    # /speech/<speech_id>/favorite
    path('<speech_id>/favorite/', views.favorite_speech, name='favorite_speech'),
]
