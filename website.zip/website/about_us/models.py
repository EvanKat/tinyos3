from django.db import models
import datetime
from django.contrib.auth.models import User


# Create your models here.


class Bureau(models.Model):
    bureau_year = models.IntegerField(default=datetime.datetime.now().year)
    bureau_president = models.CharField(max_length=100)
    bureau_vice_president = models.CharField(max_length=100)
    bureau_secretary = models.CharField(max_length=100)
    bureau_cashier = models.CharField(max_length=100)
    bureau_member1 = models.CharField(max_length=100)
    bureau_member2 = models.CharField(max_length=100, blank=True,null=True)

    def __str__(self):
        return "Bureau " + str(self.bureau_year)


class Founding_Member(models.Model):
    fm_name = models.CharField(max_length=100)
    fm_cv_link = models.CharField(max_length=1000, blank=True)

    def __str__(self):
        return self.fm_name
