from django.contrib import admin
from .models import Bureau, Founding_Member

# Register your models here.

admin.site.register(Bureau)
admin.site.register(Founding_Member)
