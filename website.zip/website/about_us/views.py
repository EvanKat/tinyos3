from django.shortcuts import render

from competition.models import Competition
from speech.models import Speech
from .models import Bureau, Founding_Member
import datetime
# add to the top
from about_us.forms import ContactForm
from django.core.mail import send_mail
from django.conf import settings
from django.contrib import messages
from django.contrib.auth.models import User


def about_us(request):
    form = ContactForm(request.POST or None)
    users = User.objects.all().count()
    all_competitions = Competition.objects.all().count()
    all_speeches = Speech.objects.all().count()
    all_events = all_competitions + all_speeches
    years_since_founding = datetime.datetime.now().year - 2013
    # new logic!
    if form.is_valid():
        print("OK")
        form_name = form.cleaned_data.get("contact_name")
        form_email = form.cleaned_data.get("contact_email")
        form_message = form.cleaned_data.get("content")
        subject = 'New email from ' + form_name + " " + form_email
        from_email = settings.EMAIL_HOST_USER
        to_email = from_email
        contact_message = " %s: %s via %s" % (form_name, form_message, form_email)
        send_mail(subject, contact_message, from_email, [to_email], fail_silently=False)
        messages.warning(request, 'Thank you for your email we will contact you soon!')
    bureau = Bureau.objects.get(bureau_year=datetime.datetime.now().year)
    previous_bureau = Bureau.objects.all().order_by("-bureau_year")[1:]
    found_mem = Founding_Member.objects.all()
    context = {
        'bureau': bureau,
        'previous_bureau': previous_bureau,
        'form': form,
        'users': users,
        'total_projects': all_events,
        'years': years_since_founding,
        'founding_members': found_mem
    }
    return render(request, 'about_us/about_us.html', context)
