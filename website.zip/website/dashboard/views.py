from itertools import chain

from django.shortcuts import render, redirect
from django.views.decorators.http import require_POST
from django.contrib.auth.models import User

from rest_framework.response import Response
from rest_framework.views import APIView

from .models import Todo
from .forms import TodoForm
from competition.models import Favorite, Team, Score, Competition, Belong
from speech.models import Favorites
from django.contrib.sessions.models import Session
from django.utils import timezone


# competition__participants__team_members__username
def dashboard(request):
    current_user = request.user
    favorite_competitions = Favorite.objects.filter(member=request.user)
    inst_favorite_competitions = Favorite.objects.filter(member=request.user).values_list(
        'competition__participants__team_name', 'competition__name', 'competition_id',
        'competition__participants__team_members__username')
    # print(inst_favorite_competitions)
    inst_belong = Belong.objects.filter(member=request.user).values_list('team__team_name', flat=True)
    string = []
    string2 = []

    for fc in inst_favorite_competitions:
        for be in inst_belong:
            if fc[0] == be:
                if not (str(fc[3]).__eq__(str(request.user))):
                    print(" Your team is: " + str(be) + " with " + str(fc[3]) + " and you are participating in  " + str(
                        fc[1]), str(fc[2]))
                    string.append(fc[1])
                    string2.append(be)

    print(string)  # competitions
    print(string2)  # teams

    for i in range(len(string2)):
        inst_favorite_competitions4 = Team.objects.filter(team_name=string2[i]).distinct().values_list('team_name',
                                                                                                       flat=True)
        print(inst_favorite_competitions4)
    #
    # print('/')
    # for i in range(len(string2)):
    #     inst_favorite_competitions3 = Belong.objects.filter(team__team_name=string2[i]).values_list('member__username',
    #                                                                                                 flat=True)
    #     print(inst_favorite_competitions3)
    #
    # print('/')
    # for i in range(len(string)):
    #     inst_favorite_competitions2 = Competition.objects.filter(name=string[i])
    #     print(inst_favorite_competitions2)
    #
    # print('/')

    favorite_speeches = Favorites.objects.filter(member=request.user)
    # favorite_events = list(chain(favorite_competitions, favorite_speeches))
    todo_list = Todo.objects.filter(user=request.user).order_by('-id')

    sessions = Session.objects.filter(expire_date__gte=timezone.now())
    uid_list = []
    # Build a list of user ids from that query
    for session in sessions:
        data = session.get_decoded()
        uid_list.append(data.get('_auth_user_id', None))

    list_of_active_users = User.objects.filter(id__in=uid_list)
    form = TodoForm()
    context = {'todo_list': todo_list,
               'form': form,
               'user': current_user,
               'favorite_competitions': favorite_competitions,
               'teams': string2,
               'count_favorite_competitions': favorite_competitions.count(),
               'count_favorite_events': favorite_competitions.count() + favorite_speeches.count(),
               'favorite_speeches': favorite_speeches,
               'list_of_active_users': list_of_active_users
               }

    return render(request, 'dashboard/dashboard.html', context)


class ChartData(APIView):
    authentication_classes = []
    permission_classes = []

    @staticmethod
    def get(request):
        qs_count = User.objects.all().count()

        score = Score.objects.values_list('score', flat=True)
        teams = Score.objects.values_list('team', flat=True)
        team = Team.get_team_id(teams[0])
        team1 = Team.get_team_id(teams[1])
        labels = ["Users", team.team_name, team1.team_name, "Green", "Purple", "Orange"]
        default_items = [qs_count, score[0], score[1], 3, 12, 2]
        data = {
            "labels": labels,
            "items": default_items,

        }
        return Response(data)


@require_POST
def addTodo(request):
    form = TodoForm(request.POST)

    if form.is_valid():
        new_todo = Todo(text=request.POST['text'])
        new_todo.user = request.user
        new_todo.save()

    return redirect('dashboard:dashboard')


def completeTodo(request, todo_id):
    todo = Todo.objects.get(user=request.user, pk=todo_id)
    if todo.complete:
        todo.complete = False
    else:
        todo.complete = True
    todo.save()

    return redirect('dashboard:dashboard')


def deleteCompleted(request):
    Todo.objects.filter(complete__exact=True, user=request.user).delete()

    return redirect('dashboard:dashboard')


def deleteAll(request):
    Todo.objects.filter(user=request.user).all().delete()

    return redirect('dashboard:dashboard')
