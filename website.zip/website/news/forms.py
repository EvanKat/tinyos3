from django import forms
from django.contrib.auth.models import User


class UserForm(forms.ModelForm):
    first_name = forms.CharField(max_length=30, required=False,widget=forms.TextInput(attrs={'placeholder': 'Optional'}))
    last_name = forms.CharField(max_length=30, required=False,widget=forms.TextInput(attrs={'placeholder': 'Optional'}))
    email = forms.EmailField(required=True,widget=forms.TextInput(attrs={'placeholder': 'Enter TUC email'}))
    password = forms.CharField(required=True, widget=forms.PasswordInput)
    confirm_password = forms.CharField(required=True, widget=forms.PasswordInput)

    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email', 'password', 'confirm_password']
