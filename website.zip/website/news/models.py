from django.db import models
import datetime
from django.contrib.auth.models import User


# Create your models here.


class Article(models.Model):
    article_image = models.ImageField(upload_to="images/news")
    article_title = models.CharField(max_length=250)
    article_date = models.DateTimeField()
    article_content = models.TextField()

    def __str__(self):
        return self.article_title


# class Event(models.Model):
#     event_name = models.CharField(max_length=250)
#     event_description = models.TextField()
#     event_date = models.DateTimeField()
#     event_images = models.FileField()
#
#     def __str__(self):
#         return self.event_name



