from django.shortcuts import render

from competition.models import Competition, Photos, Team, Compete, Score
from speech.models import Photos1
from speech.models import Speech
from .models import Article
from itertools import chain

from django.contrib.auth.models import User
from rest_framework.views import APIView
from rest_framework.response import Response


# Create your views here.

def indexview(request):
    all_articles = Article.objects.all().order_by("-article_date")
    primary_article = all_articles.all()[0]
    previous_competitions = Competition.objects.filter(expired=True).all()
    previous_speeches = Speech.objects.filter(expired=True).all()
    previous_events = sorted(chain(previous_competitions, previous_speeches), key=lambda obj: obj.date,reverse=True)

    context = {
        'primary_article': primary_article,
        'all_articles': all_articles[1:5],
        'previous_events': previous_events[:9]
    }
    return render(request, 'news/index.html', context)


def articles_list(request):
    all_articles = Article.objects.all().order_by("-article_date")
    return render(request, 'news/articles_list.html', {"all_articles": all_articles[5:]})


def article_detail(request, article_id):
    article = Article.objects.get(id=article_id)
    return render(request, 'news/article_detail.html', {'article': article})


def previous_events_list(request):
    # all_previous_competitions = Competition.objects.filter(expired=True).order_by("-date")
    # all_previous_speeches = Speech.objects.all().filter(expired=True).order_by("-date")
    # previous = list(all_previous_competitions) + list(all_previous_speeches)
    # previous_sorted = sorted(previous, key=lambda x: x.date, reverse=True)
    previous_competitions = Competition.objects.filter(expired=True).all()
    previous_speeches = Speech.objects.filter(expired=True).all()
    previous_events = list(chain(previous_competitions, previous_speeches))

    context = {
        'previous_competitions': previous_events[9:]

    }
    return render(request, 'news/previous_events_list.html', context)


def competition_event_detail(request, event_id):
    event = Competition.objects.get(id=event_id)
    # all_scores = Score.objects.get(competition=event)
    photo_class = Photos.objects.get(competition=event)
    size = 0
    photos = []
    if photo_class.picture1:
        size = size + 1
        photos.append(photo_class.picture1)
    if photo_class.picture2:
        size = size + 1
        photos.append(photo_class.picture2)
    if photo_class.picture3:
        size = size + 1
        photos.append(photo_class.picture3)
    if photo_class.picture4:
        size = size + 1
        photos.append(photo_class.picture4)
    if photo_class.picture5:
        size = size + 1
        photos.append(photo_class.picture5)
    if photo_class.picture6:
        size = size + 1
        photos.append(photo_class.picture6)

    photo_size = size

    return render(request, 'news/competition_event_detail.html',
                  {'photos': photos, 'photos_size': photo_size, 'event': event})


def speech_event_detail(request, event_id):
    event = Speech.objects.get(id=event_id)
    # all_scores = Score.objects.get(competition=event)
    photo_class = Photos1.objects.get(speech=event)
    photos = []
    size = 0
    if photo_class.picture1:
        size = size + 1
        photos.append(photo_class.picture1)
    if photo_class.picture2:
        size = size + 1
        photos.append(photo_class.picture2)
    if photo_class.picture3:
        size = size + 1
        photos.append(photo_class.picture3)
    if photo_class.picture4:
        size = size + 1
        photos.append(photo_class.picture4)
    if photo_class.picture5:
        size = size + 1
        photos.append(photo_class.picture5)
    if photo_class.picture6:
        size = size + 1
        photos.append(photo_class.picture6)

    photo_size = size

    return render(request, 'news/speeches_event_detail.html',
                  {'photos': photos, 'photos_size': photo_size, 'event': event})


class ChartData(APIView):
    authentication_classes = []
    permission_classes = []

    @staticmethod
    def get(request, event_id):
        event = Competition.objects.filter(id=event_id)

        all_scores = Score.objects.filter(competition_id=event_id).values_list('score', flat=True)

        teams = Score.objects.filter(competition_id=event_id).values_list('team', flat=True)
        all_teams = []
        for loop in teams:
            b = Team.get_team_id(loop)
            all_teams.append(b.team_name)

        labels = all_teams
        default_items = all_scores
        data = {
            "labels": labels,
            "items": default_items,
        }
        return Response(data)
