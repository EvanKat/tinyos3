from django.urls import path
from news.views import ChartData
from . import views

app_name = 'news'

urlpatterns = [
    # /competition/
    path('', views.indexview, name='index'),
    path('events/<event_id>/charts/api/charts/data/', ChartData.as_view()),
    path('articles/', views.articles_list, name='articles_list'),
    path('articles/<article_id>/', views.article_detail, name='article_detail'),
    path('previous_events/', views.previous_events_list, name='previous_events_list'),
    path('events/<event_id>/', views.competition_event_detail, name='competition_event_detail'),
    path('speech_event/<event_id>/', views.speech_event_detail, name='speech_event_detail'),

]
