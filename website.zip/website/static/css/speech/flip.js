function flip() {
    // language=JQuery-CSS
    $('.card').toggleClass('flipped');
}
alert('Hello World!');

